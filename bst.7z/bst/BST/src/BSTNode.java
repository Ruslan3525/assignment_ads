class BST_class {
    class Node {
        int a;
        Node left, right;
        public Node(int data){
            a = data;
            left = right = null;
        }
    }
    Node root;

    BST_class(){
        root = null;
    }
    void deleteKey(int key) {
        root = delete_Recursive(root, key);
    }
    Node delete_Recursive(Node root, int key)  {
        if (root == null)  return root;
        if (key < root.a)
            root.left = delete_Recursive(root.left, key);
        else if (key > root.a)
            root.right = delete_Recursive(root.right, key);
        else  {
            if (root.left == null)
                return root.right;
            else if (root.right == null)
                return root.left;
            root.a = minValue(root.right);
            root.right = delete_Recursive(root.right, root.a);
        }
        return root;
    }

    int minValue(Node root)  {
        int min = root.a;

        while (root.left != null)  {
            min = root.left.a;
            root = root.left;
        }
        return min;
    }

    void insert(int key)  {
        root = insert_Recursive(root, key);
    }

    Node insert_Recursive(Node root, int key) {
        if (root == null) {
            root = new Node(key);
            return root;
        }

        if (key < root.a)
            root.left = insert_Recursive(root.left, key);
        else if (key > root.a)
            root.right = insert_Recursive(root.right, key);
        // return pointer
        return root;
    }


    void inorder() {
        inorder_Recursive(root);
    }


    void inorder_Recursive(Node root) {
        if (root != null) {
            inorder_Recursive(root.left);
            System.out.print(root.a + " ");
            inorder_Recursive(root.right);
        }
    }

    Node search_Recursive(Node root, int key)  {

        if (root==null || root.a==key)
            return root;

        if (root.a > key)
            return search_Recursive(root.left, key);

        return search_Recursive(root.right, key);
    }
}
class Main{
    public static void main(String[] args)  {

        BST_class bst = new BST_class();

        bst.insert(45);
        bst.insert(10);
        bst.insert(7);
        bst.insert(12);
        bst.insert(90);
        bst.insert(50);
        System.out.println("The BST Created with input data(Left-root-right):");
        bst.inorder();
        System.out.println("\nThe BST after Delete 12(leaf node):");
        bst.deleteKey(12);
        bst.inorder();
        System.out.println("\nThe BST after Delete 90 (node with 1 child):");
        bst.deleteKey(90);
        bst.inorder();
        System.out.println("\nThe BST after Delete 45 (Node with 2 children):");
        bst.deleteKey(45);
        bst.inorder();


    }
}